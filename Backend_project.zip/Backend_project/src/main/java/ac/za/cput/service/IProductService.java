package ac.za.cput.service;

import ac.za.cput.domain.Product;

public interface IProductService extends IService<Product, String> {
    // No custom methods needed for now
}
