package ac.za.cput.service;

import ac.za.cput.domain.Role;

public interface IRoleService extends IService<Role, String> {
    // No custom methods needed for now
}
